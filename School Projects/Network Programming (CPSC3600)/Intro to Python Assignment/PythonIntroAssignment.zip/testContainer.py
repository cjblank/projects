class TestResultContainer:
    testDict = {
        "Throughput": [],
        "RTT": [],
        "ConnectionStatus": []
    }