For this project, I implemented a reliable data transfer protocol so that packets to travel 
between two end hosts handling data loss and corruption appropriately. Some issues that I
 had with implementing this problem consisted of working out what to check and how check 
 it in terms of determining whether or not a packet was valid in both host A and host B. I was 
 not able to correct all of the bugs that occured such as an error concerning the key of the 
 dictionary that stored the original packet from A's application layer. 
