#include <iostream>
#include <algorithm>
#include <sstream>
#include <string>
#include <random>
#include <iomanip>
#include <SDL.h>
#include "hud.h"
#include "ioMod.h"
#include "gameData.h"
#include "clock.h"
//#include "engine.h"

HUD::HUD():
    rectPosX(Gamedata::getInstance().getXmlInt("view/width")/4),
    rectPosY(Gamedata::getInstance().getXmlInt("view/height")/5),
    rectSizeW(Gamedata::getInstance().getXmlInt("view/width")/2),
    rectSizeH(Gamedata::getInstance().getXmlInt("view/height")/2),
    rectangle({rectPosX,rectPosY,rectSizeW,rectSizeH}),
    fps(0),
    instructions(""),
    fpsPos(Vector2f(rectPosX - 50, rectPosY - 50)),
    stringPos(Vector2f(rectPosX - 50, rectPosY - 100)),
    stringColor()
{
    stringColor.r = (Uint8)Gamedata::getInstance().getXmlInt("name/red");
    stringColor.g = (Uint8)Gamedata::getInstance().getXmlInt("name/green");
    stringColor.b = (Uint8)Gamedata::getInstance().getXmlInt("name/blue");
    stringColor.a = (Uint8)Gamedata::getInstance().getXmlInt("name/alpha");

    std::string str1 = Gamedata::getInstance().getXmlStr("hud/str/line1");
    std::string str2 = Gamedata::getInstance().getXmlStr("hud/str/line2");

    instructions = str1 + '\n' + str2;
}

void HUD::toggleHUD(bool toggle) const {
    if(toggle == true){
      SDL_Renderer* const renderer = IoMod::getInstance().getRenderer();
      SDL_SetRenderDrawColor(renderer, 0xff, 0, 0, 0xff);
      SDL_RenderFillRect(renderer, &rectangle);

      std::ostringstream str1;
      str1 << Clock::getInstance().getFps();

      IoMod::getInstance().writeText("FPS: " + str1.str(), fpsPos[0], fpsPos[1]);
      IoMod::getInstance().writeText(instructions, stringPos[0], stringPos[1],
        stringColor);
    }
}
