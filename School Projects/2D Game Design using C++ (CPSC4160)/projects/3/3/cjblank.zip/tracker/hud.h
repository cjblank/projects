#ifndef HUD_H
#define HUD_H
#include <vector>
#include <string>
#include <SDL.h>
#include "vector2f.h"

class HUD {
public:
    HUD();
    void toggleHUD(bool) const;
private:

    const int rectPosX;
    const int rectPosY;
    const int rectSizeW;
    const int rectSizeH;
    SDL_Rect const rectangle;
    const int fps;
    const std::string instructions;

    Vector2f fpsPos;
    Vector2f stringPos;

    SDL_Color stringColor;
};

#endif
