String to connect to database: mysql -h mysql1.cs.clemson.edu -u AnnClayDB_ynca -p AnnClayDB_uvx1
Database password: cpsc4620pw

Partner: Ann Stowasser (astowas@clemson.edu)